import{a as t}from"../chunks/entry.DN3uTyYf.js";export{t as start};
